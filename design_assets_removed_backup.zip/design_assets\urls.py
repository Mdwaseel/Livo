from django.urls import path
from . import views

app_name = "design_assets"
urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("asset/<int:pk>/", views.asset_detail, name="detail"),
    path("asset/<int:pk>/upload/", views.asset_upload, name="upload"),
    path("asset/<int:pk>/rename/", views.asset_rename, name="rename"),
    path("asset/<int:pk>/archive/", views.asset_archive, name="archive"),
    path("asset/<int:pk>/restore/", views.asset_restore, name="restore"),
    path("asset/<int:pk>/clear/", views.asset_clear, name="clear"),
    path("asset/<int:pk>/use/<int:version_number>/", views.asset_use_version,
         name="use_version"),
    path("asset/<int:pk>/download/", views.asset_download, name="download"),
    path("asset/<int:pk>/download/<int:version_number>/", views.asset_download,
         name="download_version"),
]
