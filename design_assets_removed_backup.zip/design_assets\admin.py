from django.contrib import admin

from .models import AssetCategory, AssetVersion, DesignAsset


@admin.register(AssetCategory)
class AssetCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "order")
    prepopulated_fields = {"slug": ("name",)}


class AssetVersionInline(admin.TabularInline):
    model = AssetVersion
    extra = 0
    readonly_fields = ("version_number", "file", "original_name", "file_size",
                       "width", "height", "uploaded_by", "created_at")


@admin.register(DesignAsset)
class DesignAssetAdmin(admin.ModelAdmin):
    list_display = ("name", "kind", "category", "is_archived", "updated_at")
    list_filter = ("kind", "category", "is_archived")
    search_fields = ("name", "slug")
    inlines = [AssetVersionInline]
