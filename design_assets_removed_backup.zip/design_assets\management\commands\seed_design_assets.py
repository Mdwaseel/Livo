from django.core.management.base import BaseCommand
from django.utils.text import slugify

from design_assets.models import AssetCategory, DesignAsset

COVERS = [
    "Proposal Cover", "Contract Cover", "Quotation Cover", "Invoice Cover",
    "SRS Cover", "Company Profile Cover", "Project Report Cover",
    "Meeting Minutes Cover", "Maintenance Plan Cover", "Portfolio / Case Study Cover",
]

UNIVERSAL = [
    ("PAGE", "Universal Content Page",
     "Header, footer, content area, page-number area and logo area — repeated "
     "through every generated document."),
    ("BACK", "Universal Back / Thank You Page",
     "The closing page used at the end of all generated documents."),
]

COMPONENTS = {
    "Tables": ["Pricing Table", "Feature Table", "Comparison Table",
               "Specification Table", "Payment Table", "Milestone Table"],
    "Timelines": ["Vertical Timeline", "Horizontal Timeline", "Roadmap",
                  "Project Timeline"],
    "Cards": ["Feature Card", "Service Card", "Statistic Card",
              "Testimonial Card", "Team Member Card"],
    "Checklists": ["Basic Checklist", "QA Checklist", "Deployment Checklist"],
    "Quote Blocks": ["Quote", "Tip", "Warning", "Success", "Information"],
    "Layout Components": ["Single Column", "Two Column", "Three Column",
                          "Image Left Text Right", "Image Right Text Left",
                          "Full Width Banner"],
    "Statistics": ["KPI Block", "Statistics Cards", "Progress Bar",
                   "Circular Progress"],
    "Signature Components": ["Single Signature", "Double Signature",
                             "Approval Block"],
    "Images": ["Gallery", "Hero Image", "Image With Caption"],
    "Contact Section": ["Contact Block", "Office Information", "Social Links"],
    "Dividers": ["Section Divider", "Premium Divider", "Decorative Divider"],
}


class Command(BaseCommand):
    help = "Seed the design-asset slots (covers, universal pages, component library)."

    def handle(self, *args, **opts):
        created = 0

        for i, name in enumerate(COVERS, start=1):
            _, made = DesignAsset.objects.get_or_create(
                slug=slugify(name),
                defaults=dict(kind="COVER", name=name,
                              description=f"Cover design for {name.replace(' Cover', '')} documents."),
            )
            created += made

        for kind, name, description in UNIVERSAL:
            _, made = DesignAsset.objects.get_or_create(
                slug=slugify(name),
                defaults=dict(kind=kind, name=name, description=description),
            )
            created += made

        for order, (category_name, items) in enumerate(COMPONENTS.items(), start=1):
            category, _ = AssetCategory.objects.get_or_create(
                slug=slugify(category_name),
                defaults=dict(name=category_name, order=order),
            )
            for item in items:
                _, made = DesignAsset.objects.get_or_create(
                    slug=slugify(f"{category_name}-{item}"),
                    defaults=dict(kind="COMPONENT", category=category, name=item),
                )
                created += made

        total = DesignAsset.objects.count()
        self.stdout.write(self.style.SUCCESS(
            f"Seeded design assets: {created} new, {total} total "
            f"({AssetCategory.objects.count()} component categories)."))
