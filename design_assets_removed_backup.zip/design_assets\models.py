"""
Document Design Asset Manager (Settings → Templates).

Pure asset management: the graphic designer creates designs externally
(Figma/Photoshop/Illustrator) and the administrator uploads them here.
No AI, no PDF generation, no content — the AI engine consumes these
assets later when documents are generated.
"""
from django.conf import settings
from django.db import models
from django.urls import reverse

from core.models import TimeStampedModel

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "svg", "pdf"}
MAX_UPLOAD_MB = 40


class AssetCategory(TimeStampedModel):
    """A component-library category (Tables, Timelines, Cards…)."""
    name = models.CharField(max_length=80)
    slug = models.SlugField(unique=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "name"]
        verbose_name_plural = "Asset categories"

    def __str__(self):
        return self.name


class DesignAsset(TimeStampedModel):
    """One design slot (e.g. “Proposal Cover”, “Pricing Table”).

    The slot always exists; uploading fills it with versioned files.
    """

    class Kind(models.TextChoices):
        COVER = "COVER", "Cover Template"
        PAGE = "PAGE", "Universal Content Page"
        BACK = "BACK", "Back / Thank You Page"
        COMPONENT = "COMPONENT", "Component"

    kind = models.CharField(max_length=10, choices=Kind.choices)
    category = models.ForeignKey(AssetCategory, on_delete=models.SET_NULL,
                                 null=True, blank=True, related_name="assets")
    name = models.CharField(max_length=120)
    slug = models.SlugField(unique=True)
    description = models.CharField(max_length=255, blank=True)
    is_archived = models.BooleanField(default=False)
    current_version = models.ForeignKey(
        "AssetVersion", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True
    )

    class Meta:
        ordering = ["kind", "category__order", "name"]

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("design_assets:detail", args=[self.pk])

    @property
    def has_design(self):
        return self.current_version_id is not None


class AssetVersion(TimeStampedModel):
    """One uploaded file for an asset. History is never deleted by a replace."""
    asset = models.ForeignKey(DesignAsset, on_delete=models.CASCADE,
                              related_name="versions")
    version_number = models.PositiveIntegerField(default=1)
    file = models.FileField(upload_to="design_assets/%Y/%m/")
    original_name = models.CharField(max_length=255, blank=True)
    file_size = models.BigIntegerField(default=0)
    width = models.PositiveIntegerField(null=True, blank=True)
    height = models.PositiveIntegerField(null=True, blank=True)
    note = models.CharField(max_length=200, blank=True)
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True
    )

    class Meta:
        ordering = ["-version_number"]
        unique_together = ("asset", "version_number")

    def __str__(self):
        return f"{self.asset.name} {self.label}"

    @property
    def label(self):
        return f"v{self.version_number}"

    @property
    def extension(self):
        return (self.original_name or self.file.name).rsplit(".", 1)[-1].lower()

    @property
    def is_image(self):
        return self.extension in ("png", "jpg", "jpeg")

    @property
    def is_svg(self):
        return self.extension == "svg"

    @property
    def is_pdf(self):
        return self.extension == "pdf"

    @property
    def has_thumbnail(self):
        return self.is_image or self.is_svg
