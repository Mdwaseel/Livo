from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Max, Q
from django.http import FileResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.permissions import role_required, user_can
from core.models import log_activity

from .models import ALLOWED_EXTENSIONS, MAX_UPLOAD_MB, AssetCategory, AssetVersion, DesignAsset


def _asset_queryset():
    return DesignAsset.objects.select_related("category", "current_version")


@login_required
def dashboard(request):
    """Settings → Templates: overview + all asset slots, filterable."""
    q = request.GET.get("q", "").strip()
    kind = request.GET.get("kind", "")
    category = request.GET.get("category", "")
    show_archived = request.GET.get("archived") == "1"

    assets = _asset_queryset().filter(is_archived=show_archived)
    if q:
        assets = assets.filter(Q(name__icontains=q) | Q(category__name__icontains=q))
    if kind in DesignAsset.Kind.values:
        assets = assets.filter(kind=kind)
    if category:
        assets = assets.filter(category__slug=category)

    assets = list(assets)
    covers = [a for a in assets if a.kind == DesignAsset.Kind.COVER]
    pages = [a for a in assets if a.kind in (DesignAsset.Kind.PAGE, DesignAsset.Kind.BACK)]
    components = [a for a in assets if a.kind == DesignAsset.Kind.COMPONENT]

    # group components under their category, preserving category order
    grouped, seen = [], {}
    for a in components:
        key = a.category.name if a.category else "Uncategorised"
        if key not in seen:
            seen[key] = {"category": key, "items": []}
            grouped.append(seen[key])
        seen[key]["items"].append(a)

    base = DesignAsset.objects.filter(is_archived=False)
    stats = {
        "covers": base.filter(kind=DesignAsset.Kind.COVER,
                              current_version__isnull=False).count(),
        "covers_total": base.filter(kind=DesignAsset.Kind.COVER).count(),
        "pages": base.filter(kind__in=[DesignAsset.Kind.PAGE, DesignAsset.Kind.BACK],
                             current_version__isnull=False).count(),
        "components": base.filter(kind=DesignAsset.Kind.COMPONENT,
                                  current_version__isnull=False).count(),
        "components_total": base.filter(kind=DesignAsset.Kind.COMPONENT).count(),
        "last_updated": AssetVersion.objects.aggregate(m=Max("created_at"))["m"],
    }
    recent = (_asset_queryset().filter(current_version__isnull=False, is_archived=False)
              .order_by("-updated_at")[:6])

    return render(request, "design_assets/dashboard.html", {
        "covers": covers, "pages": pages, "component_groups": grouped,
        "stats": stats, "recent": recent,
        "categories": AssetCategory.objects.all(),
        "q": q, "kind": kind, "category": category, "show_archived": show_archived,
        "kinds": DesignAsset.Kind.choices,
    })


@login_required
def asset_detail(request, pk):
    asset = get_object_or_404(_asset_queryset(), pk=pk)
    return render(request, "design_assets/detail.html", {
        "asset": asset,
        "versions": asset.versions.select_related("uploaded_by"),
    })


def _validate_upload(f):
    ext = f.name.rsplit(".", 1)[-1].lower() if "." in f.name else ""
    if ext not in ALLOWED_EXTENSIONS:
        return f"“{f.name}”: only {', '.join(sorted(ALLOWED_EXTENSIONS)).upper()} files are allowed."
    if f.size > MAX_UPLOAD_MB * 1024 * 1024:
        return f"“{f.name}” is larger than {MAX_UPLOAD_MB} MB."
    return None


def _image_dimensions(f):
    try:
        from PIL import Image
        f.seek(0)
        with Image.open(f) as img:
            return img.size
    except Exception:
        return None, None
    finally:
        f.seek(0)


@login_required
@role_required("settings")
@require_POST
def asset_upload(request, pk):
    """Upload / replace / drag-and-drop. Multiple files become successive versions."""
    asset = get_object_or_404(DesignAsset, pk=pk)
    files = request.FILES.getlist("file")
    if not files:
        messages.error(request, "No file received.")
        return redirect(asset)

    created = []
    next_number = (asset.versions.aggregate(m=Max("version_number"))["m"] or 0) + 1
    for f in files:
        error = _validate_upload(f)
        if error:
            messages.error(request, error)
            continue
        ext = f.name.rsplit(".", 1)[-1].lower()
        width = height = None
        if ext in ("png", "jpg", "jpeg"):
            width, height = _image_dimensions(f)
        version = AssetVersion.objects.create(
            asset=asset, version_number=next_number, file=f,
            original_name=f.name, file_size=f.size,
            width=width, height=height, uploaded_by=request.user,
        )
        created.append(version)
        next_number += 1

    if created:
        asset.current_version = created[-1]
        asset.save(update_fields=["current_version", "updated_at"])
        log_activity(request.user, "uploaded design", f"{asset.name} {created[-1].label}")
        messages.success(request, f"{asset.name}: {len(created)} file"
                                  f"{'s' if len(created) > 1 else ''} uploaded "
                                  f"(now at {created[-1].label}).")
    if request.headers.get("x-requested-with") == "fetch":
        return JsonResponse({"ok": bool(created)})
    return redirect(asset)


@login_required
@role_required("settings")
@require_POST
def asset_rename(request, pk):
    asset = get_object_or_404(DesignAsset, pk=pk)
    name = request.POST.get("name", "").strip()
    if name:
        old = asset.name
        asset.name = name
        asset.save(update_fields=["name", "updated_at"])
        log_activity(request.user, "renamed asset", f"{old} → {name}")
        messages.success(request, f"Renamed to “{name}”.")
    return redirect(asset)


@login_required
@role_required("settings")
@require_POST
def asset_archive(request, pk):
    asset = get_object_or_404(DesignAsset, pk=pk)
    asset.is_archived = True
    asset.save(update_fields=["is_archived", "updated_at"])
    log_activity(request.user, "archived asset", asset.name)
    messages.success(request, f"“{asset.name}” archived — hidden from the library, "
                              "nothing deleted.")
    return redirect("design_assets:dashboard")


@login_required
@role_required("settings")
@require_POST
def asset_restore(request, pk):
    asset = get_object_or_404(DesignAsset, pk=pk)
    asset.is_archived = False
    asset.save(update_fields=["is_archived", "updated_at"])
    log_activity(request.user, "restored asset", asset.name)
    messages.success(request, f"“{asset.name}” restored.")
    return redirect(asset)


@login_required
@role_required("settings")
@require_POST
def asset_clear(request, pk):
    """“Delete design”: removes every uploaded version; the slot itself remains."""
    asset = get_object_or_404(DesignAsset, pk=pk)
    count = asset.versions.count()
    for version in asset.versions.all():
        version.file.delete(save=False)
    asset.versions.all().delete()
    asset.current_version = None
    asset.save(update_fields=["current_version", "updated_at"])
    log_activity(request.user, "deleted design", f"{asset.name} ({count} versions)")
    messages.success(request, f"Deleted {count} version{'s' if count != 1 else ''} "
                              f"of “{asset.name}”. The slot is empty again.")
    return redirect(asset)


@login_required
@role_required("settings")
@require_POST
def asset_use_version(request, pk, version_number):
    """Restore a previous version — makes it current without rewriting history."""
    asset = get_object_or_404(DesignAsset, pk=pk)
    version = get_object_or_404(asset.versions, version_number=version_number)
    asset.current_version = version
    asset.save(update_fields=["current_version", "updated_at"])
    log_activity(request.user, f"switched to {version.label}", asset.name)
    messages.success(request, f"“{asset.name}” now uses {version.label}.")
    return redirect(asset)


@login_required
def asset_download(request, pk, version_number=None):
    asset = get_object_or_404(DesignAsset, pk=pk)
    if version_number is not None:
        version = get_object_or_404(asset.versions, version_number=version_number)
    else:
        version = asset.current_version
    if version is None:
        messages.error(request, "Nothing uploaded yet.")
        return redirect(asset)
    filename = version.original_name or version.file.name.rsplit("/", 1)[-1]
    return FileResponse(version.file.open("rb"), as_attachment=True,
                        filename=filename)
