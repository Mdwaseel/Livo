from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse

from .models import AssetCategory, DesignAsset

# 1×1 transparent PNG
PNG = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
       b"\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\rIDATx\x9cc\xfc\xff"
       b"\xff?\x00\x05\xfe\x02\xfe\xa75\x81\x84\x00\x00\x00\x00IEND\xaeB`\x82")


class DesignAssetManagerTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_design_assets", verbosity=0)
        User = get_user_model()
        cls.owner = User.objects.create_user("owner", password="x", role="OWNER")
        cls.dev = User.objects.create_user("dev", password="x", role="DEV")
        cls.cover = DesignAsset.objects.get(slug="proposal-cover")

    def _png(self, name="design.png"):
        return SimpleUploadedFile(name, PNG, content_type="image/png")

    def test_seed_creates_all_slots(self):
        self.assertEqual(DesignAsset.objects.filter(kind="COVER").count(), 10)
        self.assertEqual(
            DesignAsset.objects.filter(kind__in=["PAGE", "BACK"]).count(), 2)
        self.assertEqual(DesignAsset.objects.filter(kind="COMPONENT").count(), 45)
        self.assertEqual(AssetCategory.objects.count(), 11)
        call_command("seed_design_assets", verbosity=0)  # idempotent
        self.assertEqual(DesignAsset.objects.count(), 57)

    def test_dashboard_and_detail_render(self):
        self.client.force_login(self.owner)
        self.assertEqual(
            self.client.get(reverse("design_assets:dashboard")).status_code, 200)
        self.assertEqual(self.client.get(self.cover.get_absolute_url()).status_code, 200)

    def test_upload_replace_and_restore_version(self):
        self.client.force_login(self.owner)
        url = reverse("design_assets:upload", args=[self.cover.pk])
        self.client.post(url, {"file": self._png("v1.png")})
        self.cover.refresh_from_db()
        self.assertEqual(self.cover.current_version.version_number, 1)
        self.assertEqual(self.cover.current_version.width, 1)
        self.client.post(url, {"file": self._png("v2.png")})
        self.cover.refresh_from_db()
        self.assertEqual(self.cover.current_version.version_number, 2)
        self.assertEqual(self.cover.versions.count(), 2)
        self.client.post(reverse("design_assets:use_version", args=[self.cover.pk, 1]))
        self.cover.refresh_from_db()
        self.assertEqual(self.cover.current_version.version_number, 1)
        self.assertEqual(self.cover.versions.count(), 2)  # history intact

    def test_rejects_bad_extension(self):
        self.client.force_login(self.owner)
        bad = SimpleUploadedFile("hack.exe", b"MZ", content_type="application/octet-stream")
        self.client.post(reverse("design_assets:upload", args=[self.cover.pk]),
                         {"file": bad})
        self.cover.refresh_from_db()
        self.assertIsNone(self.cover.current_version)

    def test_rename_archive_restore_clear(self):
        self.client.force_login(self.owner)
        self.client.post(reverse("design_assets:upload", args=[self.cover.pk]),
                         {"file": self._png()})
        self.client.post(reverse("design_assets:rename", args=[self.cover.pk]),
                         {"name": "Main Proposal Cover"})
        self.cover.refresh_from_db()
        self.assertEqual(self.cover.name, "Main Proposal Cover")
        self.client.post(reverse("design_assets:archive", args=[self.cover.pk]))
        self.cover.refresh_from_db()
        self.assertTrue(self.cover.is_archived)
        self.client.post(reverse("design_assets:restore", args=[self.cover.pk]))
        self.cover.refresh_from_db()
        self.assertFalse(self.cover.is_archived)
        self.client.post(reverse("design_assets:clear", args=[self.cover.pk]))
        self.cover.refresh_from_db()
        self.assertIsNone(self.cover.current_version)
        self.assertEqual(self.cover.versions.count(), 0)

    def test_download_current(self):
        self.client.force_login(self.owner)
        self.client.post(reverse("design_assets:upload", args=[self.cover.pk]),
                         {"file": self._png("cover-art.png")})
        r = self.client.get(reverse("design_assets:download", args=[self.cover.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertIn("cover-art.png", r["Content-Disposition"])

    def test_non_owner_cannot_mutate_but_can_browse(self):
        self.client.force_login(self.dev)
        self.assertEqual(
            self.client.get(reverse("design_assets:dashboard")).status_code, 200)
        self.client.post(reverse("design_assets:upload", args=[self.cover.pk]),
                         {"file": self._png()})
        self.cover.refresh_from_db()
        self.assertIsNone(self.cover.current_version)
