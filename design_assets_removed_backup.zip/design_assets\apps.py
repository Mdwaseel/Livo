from django.apps import AppConfig


class DesignAssetsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "design_assets"
    verbose_name = "Design assets"
